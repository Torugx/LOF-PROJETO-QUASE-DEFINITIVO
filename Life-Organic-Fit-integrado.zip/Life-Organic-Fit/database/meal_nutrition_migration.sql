-- Life Organic Fit: migração nutricional compatível com a tabela meals legada.
-- Execute UMA VEZ no SQL Editor do mesmo projeto Supabase usado pelo app.
-- Não apaga registros existentes nem altera questionários, fórum, perfil ou IA.

begin;

-- Adiciona os campos esperados pelo serviço nutricional à tabela meals já existente.
alter table public.meals
  add column if not exists detail text,
  add column if not exists category text,
  add column if not exists logged_on date;

-- O serviço calcula valores fracionários (ex.: 42,75 kcal), então calories precisa aceitar decimal.
alter table public.meals
  alter column calories type numeric(10,2)
  using case when calories is null then null else calories::numeric(10,2) end;

-- Compatibilidade: preenche logged_on dos registros antigos usando consumed_at, quando existir.
do $$
begin
  if exists (
    select 1 from information_schema.columns
    where table_schema='public' and table_name='meals' and column_name='consumed_at'
  ) then
    execute 'update public.meals set logged_on = (consumed_at at time zone ''America/Sao_Paulo'')::date where logged_on is null';
  end if;
end $$;

update public.meals set logged_on = current_date where logged_on is null;
alter table public.meals alter column logged_on set default current_date;
alter table public.meals alter column logged_on set not null;

create table if not exists public.meal_items (
  id uuid primary key default gen_random_uuid(),
  meal_id uuid not null references public.meals(id) on delete cascade,
  food_code text,
  food_name text not null,
  brand text,
  grams numeric(10,2) not null check (grams > 0),
  calories_per_100g numeric(10,2) not null check (calories_per_100g >= 0),
  calories numeric(10,2) not null check (calories >= 0),
  created_at timestamptz not null default now()
);

create index if not exists meals_user_logged_on_idx
  on public.meals(user_id, logged_on, created_at desc);
create index if not exists meal_items_meal_id_idx
  on public.meal_items(meal_id, created_at);

alter table public.meal_items enable row level security;

grant select, insert, update, delete on public.meal_items to authenticated;

-- O acesso ao item só é permitido quando a refeição pertence ao usuário autenticado.
drop policy if exists "Users manage their meal items" on public.meal_items;
create policy "Users manage their meal items" on public.meal_items
  for all to authenticated
  using (
    exists (
      select 1 from public.meals m
      where m.id = meal_items.meal_id and m.user_id = auth.uid()
    )
  )
  with check (
    exists (
      select 1 from public.meals m
      where m.id = meal_items.meal_id and m.user_id = auth.uid()
    )
  );

commit;
