# Life Organic Fit — pacote integrado

Este pacote parte do ZIP frontend `Life-Organic-Fit-main(4)` e incorpora a implementação nutricional presente no ZIP `tccc-main(2)(1)`:
- Open Food Facts (`src/services/nutritionApi.ts`)
- registro de refeições e alimentos (`src/services/mealService.ts`)
- tela de refeições (`src/app/tabs/refeicoes.tsx`)
- migração compatível para `meals` existente e criação de `meal_items`
- dependências usadas pelo projeto TCCC

## Antes de executar
1. Faça backup do projeto e do banco.
2. Copie `.env.example` para `.env` e preencha as variáveis reais. O `supabase.ts` preservado neste pacote usa `EXPO_PUBLIC_SUPABASE_ANON_KEY`.
3. Confirme que a URL e a chave são do mesmo projeto Supabase que já contém os usuários.
4. No SQL Editor desse projeto, execute `database/meal_nutrition_migration.sql` uma vez. Faça isso após backup; a migração altera o tipo de `meals.calories` para aceitar casas decimais e adiciona colunas.
5. Instale dependências com `npm install`.
6. Execute `npx expo install --check`, `npx tsc --noEmit` e `npx expo start -c`.

## NutriIA
A tela/serviço de IA existente foi preservada. Ela depende de um endpoint externo acessível pelo aparelho, configurado em `EXPO_PUBLIC_AI_API_URL`, com contrato POST `{ messages }` e resposta `{ reply }`. Este ZIP não contém um servidor NutriIA hospedado nem credenciais; sem URL pública válida, a IA não pode ser validada de ponta a ponta.

## Open Food Facts e refeições
A pesquisa usa `https://world.openfoodfacts.org/cgi/search.pl`. A API depende de internet e da existência de dados nutricionais para o produto. O serviço grava cada refeição em `meals` e cada alimento em `meal_items`; RLS restringe os registros ao usuário dono da refeição.

## Limites desta entrega
O pacote integra os arquivos disponíveis nos dois ZIPs recebidos, mas não pode ser declarado testado com o Supabase real sem executar a migração no seu projeto e preencher `.env`. Não contém segredos nem cria hospedagem para a IA. Faça os testes de pesquisa, gravação, leitura e autenticação antes de gerar o APK.
